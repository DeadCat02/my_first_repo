# Конспекты по изучению Python

## Лекция 1

### Функция type()
Эта функция возвращает тип данных перемнной, которую мы в нее ввели. Например если *n = 123*, то *type(n)* выводит 'int'. 

### Вывод ковычек 
Если мы хотим вывести ковычки в print'e, то перед знаком ковычки надо поставить '\\'. <br>
<code>
n = "df\\'fd" <br>
print (n) <br>
// Print df'fd
</code>

### Комментирование 
Однострочный комментарий - '#' <br>
Многострочный - <code> """ code """</code> <br>
Альтернативный многострочный - выделить все строки, которые хочешь закомментить и нажать "Ctrl + C" или "Cmd + /"

### F-строки
```
a = 5 
b = 5.89 
c = "hello" 

print(f"{a} - {b} - {c}")
# or
print("{} - {} - {}".format(a,b,c))
#prints out "5 - 5.89 - hello"
```

### Функция round()

round(n,m), где n - это число, m - кол-во знаков после запятой

### Цикл for

```
for i in enumration:
# operator 1
# operator 2
```

То есть, i ведет отсчет от 0, с шагом 1, и каждый раз когда значние i будет совпадать со значением в enumeration, то будет выполняться тело цикла.



### Функция range()

* Range выдает значения из диапазона с шагом 1.
* Если указано только одно число - от 0 до заданного числа. 
* Если нужен другой шаг, то значение задает третьим аргументом

```
 r = range (5) # 0, 1, 2, 3, 4 

 r = range (2,5) # 2, 3, 4 

 r = range (0,-5) #----

 r = range (1, 10, 2) #1, 3, 5, 7, 9

 r = range (100, 0, -20) #100, 80, 60, 40, 20
 ```

#### Пример использования range() и цикла for

```
r =range (100, 0, -20)

for i in r: 
    print (i)

# 100, 80, 60, 40, 20
```

### Ряд дополнительных функций: len, lower, upper, replace
```
text = "abcdef"


print(len(text)) #prints 6 - the length of the text

print(text.upper()) #prints ABCDEF

print (text.lower()) #prints abcdef

print (abc in text) #returns true, since 'abc' is in text

print (text.replace('abc', 'ABC')) #returns ABCdef
```

### Срезы 
```
text = 'AbcdEF'
print(text[0]) #A
print(text[-1]) #F
print(text[len(text)-1]) #F
print(text[:]) #AbcdEF
print(text[:2]) #Abc
print(text[3:]) #dEF
print(text[1:-3]) #bc
print(::2) #AcE
```

# Лекция 2 - Коллекции данных. Профилирование и отладка

## Списки

``` 
list_1 = [] #создаем пустой список
list_1 = list() # тоже пустой список, только создает объект
list_1 = [1,2,3,8] # сразу создаем список со значениями
print(list_1) # будет показывать [1,2,3,8]
print(*list_1) # будет показывать 1 2 3 8
```
Со списком можно так же работать через цикл for
```
for i in list_1:
    print(i)
```

### Функция .append() - добавить элемент к концу списка

```
list_1 = [1, 5]
print(list_1)
list1.append(8) # добавляет значение '8' к концу списка
```

### Функция .pop() - удаление последнего элемента списка

```
list_1 = [12, 7, -1, 21, 0]
print(list_1.pop()) # prints 0 and now list_1 = [12, 7, -1, 21]
```

Удаление конкретного элемента:
```
list_1 = [12, 7, -1, 21, 0]
print(list_1.pop(0)) # удаляет нулевой элемент - 12
```

### .insert(a,b) Добавление новго элемента в любую позицию
```
list_1 = [12, 7, -1, 21, 0]
print(list_1.insert(2, 11)) # выводит 'none'
print(list_1) # выводит [12, 7, 11, -1, 21, 0] # добавил цифру 11 ПЕРЕД вторым элементом - '-1'. Теперь второй элемент это 11
```

## Кортежи - неизменяимый список
Кортеж занимает меньше памяти и quckly accessible. Значения никогда не меняются

```
t = () # пустой кортеж
print(type(t)) # выводит <class 'tuple'>

t = (1)
print(type(t)) # выводит <class 'int'>

t = (1, )
print(type(t)) # теперь выводит <class 'tuple'>
```

Предположим что у нас есть список и его надо преобразовать его в кортеж: 
```
v = [1, 8, 9]
print(v)
print(type(v)) #выводит <class 'list'>

v = tuple(v) #преобразовываем список в кортеж
```

### Альтернативное присваивание переменных 
```
v = ()
a = 1
b = 2
c = 3
# далее идет равносильное по смыслу
a, b, c = 1, 2, 3


#Теперь присвоим эти значние кортежу
v = a, b, c
# Now v =(1, 2, 3)
```

## Словари 
Словарь - неупорядоченная коллекция с доступом по ключу.
В списках, нашим ключом был индекс элемента, а здесь мы сами даем значение ключа

Как создать словарь:
```
d = {} #1-ый способ
d = dict() #2-ой способ
```

Добавим первое значение: 
```
d = {}
d['q'] = "qwerty"
print(d) # {'q': 'qwerty'}

d['w'] = "werty"
print(d) #{'q': 'qwerty', 'w': 'werty'}
```

Теперь выводим любой элемент 
```
print(d['q']) # qwerty
```

Удаление ключей: 
```
del dictionary['w'] # удаляет ключ и его значение
```

Как обращаться к названиям ключей?
```
for item in d:
    print('{}: {}'.format(item, d[item]))
```

### .items() - Выводим список ключей;
```
print(d.items()) # выводит пары ключ-значение в виде кортежей dict_items([('q', 'qwerty'), ('w', 'werty')])
```

### Обращаемся к словарю через цикл for 
```
for (k, v) in d.items():
    print(k, v)
# Получим q qwerty
          w werty 
```

### Обращение к значению ключа в словаре:
```
client_data.get('key')
```

Можно получить спискок всех ключей
```
client_data.keys()
```
А так же можно вывести значения этих ключей
```
client_data.values()
```

### Метод setdafult() - безопасная перезапись значений
```
client_data.setdefault('age', 14)
```

## Множества

В отличии от словаря, у множества мы не приписываем ключи:
```
colors = {'red', 'green', 'blue'} 
print(colors) # {'red', 'green', 'blue}
```
### Функция .add()

Во множестве нам не важен порядок, т.к. множество используеют для получения уникальных значений. Если нам нужна упорядоченность, то мы используем списки
```
colors = {'red', 'green', 'blue'} 
colors.add('gray')
print(colors) # {'red', 'gray', 'blue', 'green'} 
```

### Функция .remove()

Просто удаляет

```
colors.remove('gray')
```

### Функция .discard()
То же самое что и .remove(), но при отсутствии элемента он не выдает ошибку, а просто пропускает и код идет дальше

### Функция .clear()

Удаляет все значения из множества

```
colors.clear()
```

Альтернативный способ:

```
colors = set()
print(colors) # просто выводит set()
```

### Операции со множествами в Python

```
a = {1, 2, 3, 5, 8}
b = {2, 5, 8, 13, 21}

c = a.copy() # копирование
u = a.union(b) # союз
i = a.intersection(b) # пересечиния
dl = a.difference(b) # те элементы, которых не хватает у 'b'
dr = b.difference(a) # те элементы, которых не хватает у 'a'
```

## List Comprehension
Суть этой фишки состоит в том, что списки можно записывать следующим образом: 

```
list_1 = [i for i in range (1, 101)] # [1, 2, 3...100]
```

Или даже так:
```
list_1 = [i for i in range(1,101) if i%2 == 0] #[2, 4, 6,...,100]
```

## Профилирование и отладка

## .split() - Разделение слов в предложении 

Если у нас имеется строка с несколькими словами, то чтобы разбить строку на отдельные слова и вывыести все в один список, то надо использовать .split()

```
var2 = '10, 20, 30, 40, 50'
var3 = var2.split() # ['10', '20', '30', '40', '40']
```

## sorted() - Сортировка коллекции 

Если надо упорядочить нашу коллекцию, то делаем так
```
set1 = [1,5,3,4]
print(sorted(set1)) #1,3,4,5
```

# Лекция 3 - Функции, рекурсии, алгоритмы

## Функции

Объявляется функция следующим образом:
```
def function_name(x):
```

### Функция с неограниченным кол-вом аргументов
```
def sum_str(*args):
    res = ''
    for i in args: #перебирает значения всех аргументов
        res += i 
    return res
print (sum_str('q', 'w', 'r')) #qwr
```
## Модульность 

Импортирование модуля:
```
import 'указать путь файла' 
```
Импортирование определенных функций:
```
from module import max1
```
Импортирование всех функций:
```
from module import *
```
Дать модулю другое имя внутри программы 
```
import module as m
```

## Рекурсия

Пример последовательности Фиббоначи
```
def fib(n): 
    if n in [1,2]:
        return 1
    return fib(n-1) + fib(n-2)

list_1 = []
for i in range(1, 10): #выводит первые девять членов
    list_1.append(fib(i))
print(list_1)
```

## Алгоритмы

### Быстрая сортировка

```
def quick_sort(array):
    if len(array) <= 1:
        return array
    else:
        pivot = array[0]
    less = [i for i in array[1:] if i <= pivot]
    greater = [i for i in array[1:] if i > pivot]
    return quick_sort(less) + [pivot] + quick_sort(greater)

print(quick_sort([1,6,3,8,5,3]))
```

### Сортировка слиянием

```
def merge_sort(nums):
    if len(nums) > 1:
        mid = len(nums) // 2 #делим на два без остатка
        left = nums[:mid]
        right = nums[mid:]
        merge_sort(left)
        merge_sort(right)
        i = j = k = 0
        while i < len(left) and j < len(right):
            if left[i] < right [j]:
                nums[k] = left[i]
                i += 1
            else: 
                nums[k] = right[j]
                j += 1
            k +=1 

        while i < len(left):
            nums[k] = left[i]
            i += 1
            k += 1

        while j < len(right):
            nums[k] = right[j]
            i += 1
            k += 1

list1 = [1, 6, 3, 9, 10, 45, 9, 5, 40]
merge_sort(list1)
print(list1)
```

# Лекция 4 - повторение списков

# Лекция 5 - функции высшего порядка, работа с файлами
Пример на калькуляторе

```
def plus(x, y):
    return x+y

def minus(x, y):
    return x-y

def calc(op, x, y):
    return op(x,y)

print(calc(plus,1,5))
```

## Лямбда-функции

Заменяем функцию 'plus' на лямбда-функцию, чтобы упростть код

```
def minus(x, y):
    return x-y

def calc(op, x, y):
    return op(x,y)

plus = lambda a,b: a+b

print(calc(plus,1,5))
```

Можно сделать еще большее сокращение, вписав лямбда-функцию в print()

```
print(lambda a,b: a+b, 1, 5)
```

Есть задача на лямбда функции: дан список числе, надо вывести четные числа в паре с и квадратом. Такая задача решается с помощью list comprehension
```
numbers = [1, 2, 3, 5, 8 ,15, 23, 38]
new_numbers = [(i, i**2) for i in numbers if i%2==0]
print(new_numbers)
```

Теперь посмотрим как ее решать с помощью лямбда-функций:
```
def select(f, col):
    return [f(x) for x in col]

def where(f, col):
    return [x for x in col if f(x)]

data = [1, 2, 3, 5, 8 ,15, 23, 38]

res = select(int, data) # переводим списоск 'data' в целочисленный

res = where(lambda x: x%2==0, res) #Теперь в списке res находятся только четные числа

res = select(lambda x: (x, x**2), res) #Возводим все полученные числа в квадрта и создаем кортеж из пар - число и его квадрат.

print(res)
```

## Функция map()

```
list_1 = [x for x in range(1, 20)]
print(list_1)

list_1 = list(map(lambda x: x+10, list_1)) #К каждому элементу списка list_1 применяется лямбда-функция 
print(list_1)
```

Задача

```
data = '15 156 96 3 5 8 52 5'

data = list(map(int, data.split())) # К каждому объекту из разделенного списка data.split(), мы применяем функцию int() - преобразовываем объект в целочисленное значние
```

### Упрощение предыдущей задачи с помошью функции map()
```
def where(f, col):
    return [x for x in col if f(x)]

data = [1, 2, 3, 5, 8 ,15, 23, 38]

res = map(int, data) # переводим списоск 'data' в целочисленный

res = where(lambda x: x%2==0, res) #Теперь в списке res находятся только четные числа

res = list(map(lambda x: (x, x**2), res)) #Возводим все полученные числа в квадрта и создаем кортеж из пар - число и его квадрат.

print(res)
```

## Функция filter()
```
data = [15, 65, 9, 36, 175]
res = list(filter(lambda x: x%10 == 5, data)) # Оставляет только те элементы, которые соответствуют условию лямбда-функции
print(res)
```

### Упрощение предыдущей задачи с помошью функции filter()

```
data = [1, 2, 3, 5, 8 ,15, 23, 38]

res = map(int, data) # переводим списоск 'data' в целочисленный

res = filter(lambda x: x%2==0, res) #Теперь в списке res находятся только четные числа

res = list(map(lambda x: (x, x**2), res)) #Возводим все полученные числа в квадрта и создаем кортеж из пар - число и его квадрат.

print(res)
```

## Функция zip()

Работает следующим образом - предположим, у нас есть список 
```
n = [[1, 2, 3], ['a', 'b', 'c'], ['f', 's', 't']]
```
Если применить к нему функцию zip(), то
```
print(zip(n))
# [(1, 'a', 'f'), (2, 'b', 's'), (3, 'c', 't')]
```

Примечание: функция zip() пробегает по минимально входящему набору, то есть если если в функции zip(list1, list2, list3) будет лист с самой минимальной длиной, то и кол-во кортежей будет столько же.

## Функция enumerate()

Эта функция позволяет пронумеровать набор данных.
```
list1 = ['a', 'b', 'c']
print(list(enumerate(list1)))
```

## Файлы

Режимы файла (мод)

a - открытие для добавления данных (дописывает)<br>
r - окрытие для чтения данных (читает) <br>
w - открытие для записи данных (записывает) <br>
w+ - открыть для записи + чтения <br>
r+ - открыть для чтения + дописывать <br>

Пример 

```
colors = ['red', 'green', 'blue']
data = open('file.txt', 'a') #открываем файл для добавления данных
data.writelines(colors) #без разделителей
data.close()
```

Чтобы постоянно не открывать/закрывать файл, мы используем следующее:

```
with open('file.txt', 'w') as data:
    data.write('line 1\n')
    data.write('line 2\n')
```

Следующий код позволяет пройтись по каждой отдельной линии наешго файла и распечатать ее:

```
path = 'file.txt'
data = open('file.txt','r')
for line in data:
    print(line)
data.close()
```

### Модуль os
Этот модуль предоставляет множество функция для работы с операционной системой

Сперва модуль надо импортировать
```
import os
```

```
os.chdir(path) # смена текущей рабочей директории
print(os.getcwd()) #показывает текущуюю рабочую директорию
print(os.path.basename('path')) #базовое имя пути
print(os.path.abspath('main.py)) #возвращает полный путь к файлу
```

### Модуль shutil

Этот модуль содержит набор функция для обработки файлов, груп файлов, и папок

```
import shutil
shutil.copyfile(src, dst) #копирует данные файла src в файл dst
shutil.copy(src, dst) #копирует содержимое файла src в папку dst
shutil.rmtree(path) #удаляет текущую директорию и все поддериктории 
```

# Лекция 6 - Google Colab (Jupyter). Знакомство с аналитикой

![image](PythonNotes_Screens/Lecture6_1.png)

## Библиотека pandas

Эта библиотека позволяет нам считывать многие форматы файлов (текстовик, экзель и т.д.)

```
import pandas as pd #импортирование библиотеки
```

## Чтение файла с помощью pandas

```
df = pd.read_csv('Filepath')
df.head(n=10) #выводит первые 10 строк
df.tail(n=10) #выводит последник 10 строк
df.shape #выводит - (кол-во строк, кол-во столбцов)
df.isnull() #проверяет, является ли значение нулевым и ставит true/false
df.insull().sum() #суммирует все значения в столбце
df.dtypes #выводит тип данных каждого столбца
df.columns #выводит названия всех столбцов
```

## Выборка Данных 

```
df['latitude'] #выводит значения столбца latitude
```

Пример: вывести столбец total_rooms, у кооторого медианный возраст здания меньше 20

```
df[df['housing_median_age'] < 20]['total rooms']
```

### Союзы & и |

```
df[(df['housing_median_age] <20) & (df'housing_median_age' > 10)][['total_rooms', 'house_median_age']]
```

## Простая статистика

```
print(df['population'].max()) # Макс. значение столбца
print(df['population].mean())
print(df['population'].sum())
df[['population', 'total_rooms']].median()
df.describe() #выводит общий анализ таблицы
```

## Изображение статистических отношений

Scatterplot (Точечный график) - мат. диаграмма, которая изображает 

Для изображения отношений между двумя столбцами, мы используем библиотеку seaborn.

```
import seaborn as sns
```

Изображение точек долготы по отношению к широте:
```
sns.scatterplot(data=df, x='longitude', y='latitude')
```

Можно визуализировать сразу несколько отношений, используя PairGrid внутри seaborn. PairGrid прикинимает как аргумент pandas DataFrame и визуализирует все возмонжые отношения между ними. 

То есть, нам покажут отношение population ко всем остальным (и отноешние к себе тоже), потом отношение median_income и т.д.

```
cols = ['population', 'median_income', 'housing_median_age', 'median_house_value']
g = sns.PairGrid(df[cols])
g.map(sns.scatterplot)
```
![image](PythonNotes_Screens/Lecture6_2.png)
### Линейные графики

```
sns.relplot(x="latitude", y="median_hous_value", kind="line", data=df)
```

![image](PythonNotes_Screens/Lecture6_3.png)

Теперь визуализируем отношение широты к долготе и в виде оттенков обозначим цену домов

![image](PythonNotes_Screens/Lecture6_4.png)

### Гистограмма

Чтобы сделать столбчатую диаграмму, мы делаем так:

```
sns.histpplot(data = df, x ='median_income')
```

![image](PythonNotes_Screens/Lecture6_5.png)

Теперь построим такую диаграмму по другим показателям

```
sns.histplot(data =df, x ='housing_median_age')
```
![image](PythonNotes_Screens/Lecture6_6.png)

Теперь посмотрим гистограмму тех данных, которые соответтсвтуют определенному критерию. Например здесь мы берем только те housing_median_age, которые больше 50

```
sns.histplot(data=df[df['housing_median_age]>50], x="median_income")
```
![image](PythonNotes_Screens/Lecture6_7.png)

Теперь мы построим гистограмму, в которой по оси 'x' = 'median_house_value', и оттенок hue = 'housing_median_age'

```
sns.displot(data = df, x = 'median_house_value', hue = 'housing_median_age')
```
![image](PythonNotes_Screens/Lecture6_11.png)


В таблицу можно добавить новую колонку для возрастных групп. Значение этой колонки будет зависеть от 'housing_median_age'

```
df.loc[df['housing_median_age']<=20, 'age_group'] = 'Молодые'
df.loc[(df['housing_median_age] > 20) & (df['housing_median_age'] <=50), 'age_group']='Ср. возраст'
df.loc[df['housing_median_age']>50, 'age_group'] = 'Пожилые'
```

![image](PythonNotes_Screens/Lecture6_8.png)

Теперь мы применяем **group_by**, чтобы получить среднее значение. 



```
df.groupby('age_group')['median_income'].mean().plot(kind='bar')
```

![image](PythonNotes_Screens/Lecture6_9.png)

Seaborn позволяет смотреть распределение по многим параметрам

Например: поделим группы по доходам. У нас будут две группы - богатые и остальные. 

```
df.loc[df['median_income'] > 6, 'income_group'] = 'rich'
df.loc[df['median_income'] < 6, 'income_group'] = 'everyone_else'
```

![image](PythonNotes_Screens/Lecture6_10.png)

Теперь построим гистограмму:

* Указываем наш датафрейм
* Что у нас будет выводиться по оси 'x'
* По какому критерию будем меняться оттенок
```
sns.histplot(data = df, x = 'median_house_value', hue = 'income_group')
```

# Семинар - построение графиков

## Пишем EDA

Функция PairGrid

# Лекция 7 - Продолженние знакомства с Jupyter

